const express = require("express")
const app = express()
const sequelize = require("./config/database")

app.use(express.urlencoded({ extended: true }))
app.use(express.static("public"))
app.set("view engine", "ejs")

require("./models/History")

sequelize.sync().then(() => {
  console.log("Database SQLite siap")
})

const mesinRoutes = require("./routes/mesin")
app.use("/", mesinRoutes)

app.listen(3000, () => {
  console.log("Server jalan di http://localhost:3000")
})