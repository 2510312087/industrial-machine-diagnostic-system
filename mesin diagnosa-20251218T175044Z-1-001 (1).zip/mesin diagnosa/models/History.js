const { DataTypes } = require("sequelize")
const sequelize = require("../config/database")

const History = sequelize.define("History", {
  suhu: DataTypes.FLOAT,
  getaran: DataTypes.FLOAT,
  suara: DataTypes.FLOAT,
  beban: DataTypes.FLOAT,
  mode: DataTypes.STRING,

  status: DataTypes.STRING,
  risiko: DataTypes.STRING,
  health: DataTypes.INTEGER,
  rekomendasi: DataTypes.TEXT,
  ai: DataTypes.TEXT
})

module.exports = History