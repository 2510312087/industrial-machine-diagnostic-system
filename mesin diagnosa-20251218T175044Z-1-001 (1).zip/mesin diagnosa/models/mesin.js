class Mesin {
  constructor(suhu, getaran, suara, beban, mode) {
    this.suhu = suhu
    this.getaran = getaran
    this.suara = suara
    this.beban = beban
    this.mode = mode
  }
}

class MesinIndustri extends Mesin {
  analisa() {
    let status = "AMAN"
    let risiko = "Low"
    let rekomendasi = "Operasi normal"
    let ai = "Tidak diperlukan tindakan"

    if (this.mode === "overload") this.suhu += 5

    if (this.suhu > 80 || this.getaran > 7 || this.beban > 85) {
      status = "PERINGATAN"
      risiko = "Medium"
      rekomendasi = "Kurangi beban dan lakukan monitoring"
      ai = "AI merekomendasikan penurunan beban 10–20% dan pengecekan sistem pendingin"
    }

    if (this.suhu > 90 && this.getaran > 8) {
      status = "BAHAYA"
      risiko = "High"
      rekomendasi = "Hentikan mesin segera"
      ai = "AI mendeteksi risiko kerusakan bearing dan motor, inspeksi menyeluruh diperlukan"
    }

    const health = Math.max(
      100 - (this.suhu * 0.4 + this.getaran * 5 + this.beban * 0.3),
      0
    )

    return {
      status,
      risiko,
      rekomendasi,
      ai,
      health: Math.round(health)
    }
  }
}

module.exports = MesinIndustri