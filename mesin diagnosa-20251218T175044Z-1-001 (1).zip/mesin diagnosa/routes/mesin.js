const express = require("express")
const router = express.Router()
const MesinIndustri = require("../models/Mesin")
const History = require("../models/History")

let mesin = null

router.get("/", (req, res) => {
  res.render("input")
})

router.post("/input", (req, res) => {
  const { suhu, getaran, suara, beban, mode } = req.body
  mesin = new MesinIndustri(+suhu, +getaran, +suara, +beban, mode)
  res.redirect("/proses")
})

router.get("/proses", async (req, res) => {
  if (!mesin) return res.redirect("/")

  const hasil = await new Promise(resolve =>
    setTimeout(() => resolve(mesin.analisa()), 1000)
  )

  await History.create({
    suhu: mesin.suhu,
    getaran: mesin.getaran,
    suara: mesin.suara,
    beban: mesin.beban,
    mode: mesin.mode,
    status: hasil.status,
    risiko: hasil.risiko,
    health: hasil.health,
    rekomendasi: hasil.rekomendasi,
    ai: hasil.ai
  })

  res.render("proses", { hasil })
})

router.get("/riwayat", async (req, res) => {
  const logs = await History.findAll({
    order: [["createdAt", "DESC"]]
  })
  res.render("riwayat", { logs })
})

module.exports = router